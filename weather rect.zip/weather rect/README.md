## Weather App
================================================================================================

A weather app that tracks and displays minimum, maximum, average, and real-time temperatures with live, interactive charts for historical data. Users receive threshold alerts when temperatures exceed set limits, providing timely insights. It’s ideal for real-time monitoring, trend analysis, and staying updated on temperature fluctuations.

## Features

- **Temperature Tracking**: Displays minimum, maximum, average, and actual temperatures in real-time.
- **Historical Data Visualization**: Interactive charts show temperature trends over time for in-depth analysis.
- **Threshold Alerts**: Notifies users when temperature values exceed predefined limits.
- **User-Friendly Interface**: A simple, responsive layout for easy navigation and quick insights.  

## Tech Stack

- **Frontend**: HTML, CSS, JavaScript, React
- **Database**: MongoDB
- **Charts**: Chart.js or react-chartjs-2 for live data visualization
- **APIs**: Weather API for temperature data retrieval

### A Go through
Start the Project using following command
npm start 
It will start running on localhost 3000 on the default browser

![alt text](image-1.png)

A placard showing each metro cities temperature data fetched from openweathermapApi which gets updated in 5 min interval.

![alt text](image-2.png)

User can choose option to see the temperature data in Celsius or Fahrenheit.

The chart contains historical data recording from open-meteo Api.

![alt text](image-3.png)

Along with that User can also set threshold value (amount of deviation from average temp ) showcased in red dots in the charts.



